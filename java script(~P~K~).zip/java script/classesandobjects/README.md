# classes-and-objects-in-java-script
basic knowledge about classes and objects
