// const product = {
//     title:"ball pen",
//     ratin:4,
//     price:250,
//     offer:5,
// };
// console.log(product);
// const profile={
// name:"shradda khaper",
// followers:500,
// following:10,
// status: "enterpreneour" ,
// };
// console.log(profile);
// // 
// let a=5;
// let b=2;
// console.log(a+b);
// console.log(a-b);
// console.log(a/b);
// console.log(a*b);
// console.log(a%b);
// console.log(a**b);
// // uanry opertor
// let c=5;
// c++;
// console.log(++c);
// //comparision operator
// let d=6;
// let e=5;
// // console.log(d>=e);
// let color;
// let mode= "dark-mode" ;
// if(mode=="dark-mode") {
//     color="black";
// }else{
//     color="white";
// }
// console.log(color);
// let age=25;
// age=19;
// if(age>18){
//     console.log("you can vote");
// }else{
//     console.log("you can not vote")
// }
// let a=5;
// if(a%2==0){
//     console.log(a+  ":it is even number");
// }else{
//     console.log(a+">odd number");
// }
// let age=39;
// if(age<18){
//     console.log(age,"you are my children");
// }
// else if(age>60){
//     console.log(age,"you are my daddu");
// }
// else if(age>30&&age<60){
//     console.log(age,"who are you");
// }
// else{
//     console.log(age,"i am you father");
// }
// let age=19;
// console.log(age>18?"vote":"no vote");
// let number=prompt("hello");
// if(number%5==0){
//     console.log("it is multiple of 5");
// }else{
//     console.log("not divisible of 5");
// }

// for(let i=0;i<5;i++){
// console.log("king :piyush khandelwal")
// }
// let a=10;
// while(a>0){
//     console.log(a);
//     a--;
// }
// let b=11;
// do{
//     console.log(b);
//     b--;
// }while(b>0);
// let str="piyush khandelwal"
// let length=0;
// for(let i of str){//iterator me single single charactor aayenge 
//     console.log("i="+i);
//     length++;
// }
// console.log("string size:"+length);
// const student = {
//     name:"piyush",
//     id:122,
//     age:9.388,
//     ispass:true,


// }
// for(let i in student){
//     console.log(i+student[i]);
// }
// for(let i=0;i<=100;i++){
//     if(i%2==0){
//         console.log(i);
//     }
// }


// let gamenum=25;
// let name=prompt("enter a number");
// while(gamenum!=name){
// name=prompt("enter a number you guess the wrong umber");
// console.log(name);
// }
// console.log("congrats you win");


// let str="piyush k";
// let str2='piyush k';
// console.log(str.length);

// // templates
// let obj = {
//     price: 10,
//     name: "pen",
// }
// console.log("cost of pen "+obj[name]+"is"+obj.price);
// let output=`the cost of ${obj.name} is ${obj.price} ruppess`;
// console.log(output);
// let sentence=`this is a template`;
// console.log(sentence);


// console.log()
// let str="    piyus khandelwal   "
// console.log(str.toUpperCase());
// console.log(str.toLocaleUpperCase());
// console.log(str.toLowerCase());
// console.log(str.toLocaleLowerCase());
// console.log(str.trim());
// console.log(str.slice(0,10));

// let str1="hello";
// let str2="world";
// let res=str1.concat(str2);
// console.log(res);

// str1.replace("h","y")
// console.log(str1.replace("h","y"));
// let str3="i love javascript"
// console.log(str3.charAt(0));
// let name=prompt("enter your name:");
// let co=name.length;
// let output=`password: @${name}${co}`;

// console.log(output);  



// array.....................................................................................................
// let piyush=["piyush","khandelwal" ];
// let marks=[10,20,30,40,50,60];
// console.log(piyush);
// console.log(piyush.length);
// console.log(marks.length);
// console.log(typeof(marks));
// let n=marks.length;
// for(let i=0;i<n;i++){
//     console.log(marks[i]);
// }

// let marks=[85,97,44,37,76,60];
// let n=marks.length;
// let sum=0;
// for(let i=0;i<n;i++){
// sum=sum+marks[i];
// }
// let avarage=(sum/n);
// console.log("avarage:"+avarage);

// let price=[250,645,300,900,50];
// for(let i=0;i<price.length;i++){
//     let off=(0.10*price[i]);
//     price[i]=price[i]-off;
//     console.log(price[i]);
// }
// price.push(25);
// console.log(price);
// price.pop(25);
// console.log(price);
// console.log(price.toString());
// let both=marks.concat(price);
// console.log(both);
// price.unshift(250);
// console.log(price);
// price.shift(250);
// console.log(price);
// // for(let i=0;i<price.length;i++){

// //     console.log(price[i]);
// // }


// let company=[ "bloomberg","microsoft","ubser","google","idm","netfliz"];
// company.shift("bloomberg");
// company[2]="ola";
// company.push("amazon");
// console.log(company);

// function hello(){
//     console.log("jai mata di");
//     console.log("jai shree ram")
// }
// hello();
// c

// 
// function vowel(s){
//    let n=s.length;
//    for(let i=0;i<n;i++){
//     if(s[i]=="a"|s[i]=="e"|s[i]=="i"|s[i]=="o"|s[i]=="u"){
//         console.log("vowels:"+s[i]);
//     }
//    }
// }
// 


// let arr=[1,2,3,4,5];
// arr.forEach(function printval(val){
//     console.log(val*val);
// })

// let marks=[50,40,90,95,80,60];
// let topper=marks.filter((value)=>{
//     return value>90;
// }
// )
// console.log(topper);


// let arr=[];
// let n=prompt("enter a value");
// for(let i=0;i<n;i++){
// arr[i]=i+1;

// }
// console.log(arr);
// let sum=arr.reduce((prev,result)=>{
//     return prev+result;
// })
// let fact=arr.reduce((prev,result)=>{
//     return prev*result;
// })
// console.log(sum);
// console.log(fact);
// alert("apna collegae");
// let heading=document.getElementById("heading");
// console.log(heading);

// let heading=document.getElementsByClassName("heading");
// console.log(heading);
// heading.tagName; 
// console.dir(document.body.firstChild); 

// let h2=document.querySelector("h2");
// console.dir(h2);

// console.log(h2.innerText);
// h2.innerText=h2.innerText+" from piyush khandelwal";

// let hello=document.querySelectorAll(".box");
// console.dir(hello);
// console.log(hello[0]);
// console.log(hello[1]);
// console.log(hello[2]);
// hello[0].innerText="jai";
// hello[1].innerText="jai";
// hello[2].innerText="jai";

// let div=document.querySelector("div");
// console.dir(div);
// let id=div.setAttribute("id","jaimatadi");
// console.dir(id);
// let name=div.getAttribute("name");
// console.log(name);
// let p=document.querySelector("p");



////////////////////////////////////////////////////////////////////////////////////////

// let button=document.createElement("button");
// button.innerText="click me";
// console.dir(button);
// let div=document.querySelector("div");
// div.append(button);
// // div.remove(button);

// let element=document.createElement("button");
// element.innerText="clickme!";
// element.style.color="white";
// element.style.backgroundColor="red";
// let body=document.querySelector("body").prepend(element);

// let para=document.querySelector("p");
// para.getAttribute("class");


////////////events.................................................................................
// let button=document.querySelector("div");
// let a=1;
// button.onclick=(e)=>{

//     console.log("button was clicked at times:"+ a);
//     a++;
//     console.log(e);
// }
// const handler3 = () => {
//     console.log(("div clicked--handler 3 "));
// }
// button.addEventListener("click",()=>{
//     console.log(("div clicked--handler 1 "));
// })
// button.addEventListener("click",()=>{
//     console.log(("div clicked--handler 2 "));
// })
// button.addEventListener("click",handler3)
// button.addEventListener("click",()=>{
//     console.log(("div clicked--handler 4 "));
// })

// button.removeEventListener("click",handler3)
// let btn=document.querySelector("button");
// let b=1;
// btn.onmouseover=(e)=>{
//     console.log("you inside button");
// }
let current="light";


let mode=document.querySelector("#mode");
mode.addEventListener("click",()=>{
   if(current=="light"){
    current="dark";
    document.querySelector("body").style.backgroundColor="black";
   }else{
    current="light";
    document.querySelector("body").style.backgroundColor="white";
   }
   console.log(current);
})