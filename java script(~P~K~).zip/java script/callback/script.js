// function hello(){
//     console.log("hello ");
// }


// setTimeout( () => {
   
//         console.log("hello ");
    
// },2000);//
// console.log("jai mata di");

// function sum(a,b){
//     console.log(a+b);
// }
// function calculator(a,b,sumcallback){
// sumcallback(a,b);
// }

// calculator(1,2,sum);

/*function getdata(dataid,getnextdata){
    setTimeout(()=>{
        console.log("data",dataid);
        if(getnextdata){
        getnextdata();
        }
    },2000);
}



//call back hell code -------pyramid of doom ------//
getdata(1,() => {
    getdata(2,()=>{
        getdata(3,()=>{
            getdata(4);
        });
    });
});
//-----//to solve callback hell problem we use promises ....................
// we can use callback but where it became greater use promises*/



// const getpromise = () => {
//      return new Promise((resolve,reject) => {
//         console.log("i am promise");
//         // resolve("success");
//         // resolve(123);
//        reject("some unknown error cming")
//     });
// }
// let promise = getpromise();
// promise.then((res) =>{
//     console.log("promise fulfilled"+res);
// });
// promise.catch((err)=>{
//     console.log("rejected"+err);
// })


function asyncfunc(){
    return new Promise((resolve,reject)=>{
        setTimeout( () => {
            console.log("data");
            resolve("success");
        },2000);
    });
}
console.log("getting data 1")
let p1=asyncfunc();
p1.then((res) => {
    console.log(res)
})